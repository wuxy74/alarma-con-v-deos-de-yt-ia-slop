package com.despertador.ytalarm

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import java.net.HttpURLConnection
import java.net.URL
import kotlin.random.Random

object Net {
    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

    fun get(url: String, timeoutMs: Int = 9000): String? {
        var c: HttpURLConnection? = null
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            c = conn
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            conn.setRequestProperty("Cookie", "SOCS=CAI; CONSENT=YES+cb")
            if (conn.responseCode != 200) null
            else conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }
}

object Playback {
    /** Lee los vídeos de una lista (hasta ~100 por la página, 15 por el RSS si la página falla). */
    fun fetchPlaylist(list: String): List<String> {
        val html = Net.get("https://www.youtube.com/playlist?list=$list&hl=en", 10000)
        var ids = if (html != null) YT.idsFromPlaylistHtml(html) else emptyList()
        if (ids.isEmpty()) {
            val xml = Net.get("https://www.youtube.com/feeds/videos.xml?playlist_id=$list")
            if (xml != null) ids = YT.idsFromRss(xml)
        }
        return ids
    }

    /** Descarga la lista y la guarda. Devuelve cuántos vídeos se leyeron. */
    fun refresh(ctx: Context, list: String): Int {
        val ids = fetchPlaylist(list)
        if (ids.isNotEmpty()) Config(ctx).saveIds(list, ids)
        AlarmLog.d(ctx, "Lista $list: ${ids.size} vídeos leídos")
        return ids.size
    }

    /** Elige qué se reproduce. Con lista y azar activado, un vídeo aleatorio de la lista. */
    fun resolve(ctx: Context, allowNetwork: Boolean): Target {
        val cfg = Config(ctx)
        val ref = YT.parse(cfg.url) ?: return Target(null, null, -1)
        val list = ref.list ?: return Target(ref.video, null, -1)
        var ids = cfg.ids(list)
        if (ids.isEmpty() && allowNetwork) {
            refresh(ctx, list)
            ids = cfg.ids(list)
        }
        if (cfg.shuffle && ids.isNotEmpty()) {
            val i = Random.nextInt(ids.size)
            return Target(ids[i], list, i)
        }
        val v = ref.video ?: ids.firstOrNull()
        val idx = if (v == null) -1 else ids.indexOf(v)
        return Target(v, list, idx)
    }
}

data class PlayerApp(val pkg: String, val label: String)

object Players {
    private val KNOWN = listOf(
        "app.revanced.android.youtube",
        "app.rvx.android.youtube",
        "app.morphe.android.youtube",
        "com.vanced.android.youtube",
        "com.google.android.youtube"
    )

    /** Apps que pueden abrir un enlace de YouTube (ReVanced primero). */
    fun detect(ctx: Context): List<PlayerApp> {
        val pm = ctx.packageManager
        val found = LinkedHashMap<String, String>()
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
                .addCategory(Intent.CATEGORY_BROWSABLE)
            for (r in pm.queryIntentActivities(i, PackageManager.MATCH_ALL)) {
                val p = r.activityInfo.packageName
                val low = p.lowercase()
                if (low.contains("youtube") || low.contains("revanced") || low.contains("rvx") || low.contains("morphe")) {
                    found[p] = r.loadLabel(pm).toString()
                }
            }
        } catch (e: Exception) {
            AlarmLog.d(ctx, "Error buscando apps: ${e.message}")
        }
        for (p in KNOWN) {
            if (found.containsKey(p)) continue
            try {
                found[p] = pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString()
            } catch (e: Exception) {
            }
        }
        return found.map { PlayerApp(it.key, it.value) }.sortedBy {
            val l = it.pkg.lowercase()
            if (l.contains("revanced") || l.contains("rvx") || l.contains("morphe")) 0 else 1
        }
    }
}
