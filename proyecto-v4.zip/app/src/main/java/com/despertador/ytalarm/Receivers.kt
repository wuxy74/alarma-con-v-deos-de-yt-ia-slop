package com.despertador.ytalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        AlarmLog.d(ctx, "La hora de la alarma ha llegado")
        val c = Config(ctx)
        c.firedTrigger = c.nextTrigger
        Scheduler.afterFire(ctx)
        try {
            AlarmService.start(ctx, test = false, boot = false)
        } catch (e: Exception) {
            AlarmLog.d(ctx, "No se pudo iniciar el servicio: ${e.message}")
        }
    }
}

/**
 * Tras reiniciar (o cambiar la hora) hay que volver a programar la alarma.
 * Si el móvil arranca hasta 15 minutos después de la hora (encendido programado), suena al arrancar.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val action = intent.action ?: return
        AlarmLog.d(ctx, "Evento del sistema: $action")
        val c = Config(ctx)
        if (!c.enabled) return
        val now = System.currentTimeMillis()
        val due = c.nextTrigger
        val isBoot = action == Intent.ACTION_LOCKED_BOOT_COMPLETED || action == Intent.ACTION_BOOT_COMPLETED

        if (isBoot && due in 1..now && now - due <= 15 * 60_000L && c.firedTrigger != due) {
            AlarmLog.d(ctx, "El móvil arrancó poco después de la hora: suena ahora")
            c.firedTrigger = due
            Scheduler.afterFire(ctx)
            try {
                AlarmService.start(ctx, test = false, boot = true)
            } catch (e: Exception) {
                AlarmLog.d(ctx, "No se pudo iniciar el servicio: ${e.message}")
            }
            return
        }
        try {
            if (due in 1..now && c.days == 0) {
                c.enabled = false // alarma única que ya pasó
            } else {
                Scheduler.schedule(ctx)
            }
        } catch (e: Exception) {
            AlarmLog.d(ctx, "No pude reprogramar: ${e.message}")
        }
    }
}
