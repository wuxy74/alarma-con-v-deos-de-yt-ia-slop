package com.despertador.ytalarm

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.RingtoneManager
import kotlin.math.sin

/** Tono de alarma de respaldo. Intenta el tono del sistema; si falla (p. ej. antes de desbloquear), genera pitidos. */
class ToneAlarm(private val ctx: Context) {
    private var mp: MediaPlayer? = null
    private var track: AudioTrack? = null
    private var thread: Thread? = null
    @Volatile private var synthRunning = false

    fun start() {
        stop()
        try {
            val am = ctx.getSystemService(AudioManager::class.java)
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        } catch (e: Exception) {
        }
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            p.setDataSource(ctx, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            p.isLooping = true
            p.setOnErrorListener { _, _, _ ->
                try { p.release() } catch (e: Exception) { }
                mp = null
                startSynth()
                true
            }
            p.prepare()
            p.start()
            mp = p
        } catch (e: Exception) {
            AlarmLog.d(ctx, "Tono del sistema no disponible (${e.message}); uso pitidos")
            try { mp?.release() } catch (x: Exception) { }
            mp = null
            startSynth()
        }
    }

    private fun startSynth() {
        if (synthRunning) return
        synthRunning = true
        try {
            val rate = 22050
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val fmt = AudioFormat.Builder()
                .setSampleRate(rate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack(attrs, fmt, maxOf(minBuf, rate), AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE)
            track = t
            t.play()
            thread = Thread {
                val beep = ShortArray(rate / 5) { i -> (sin(2.0 * Math.PI * 880.0 * i / rate) * 0.8 * Short.MAX_VALUE).toInt().toShort() }
                val gap = ShortArray(rate / 10)
                val pause = ShortArray(rate / 2)
                try {
                    while (synthRunning) {
                        for (k in 0 until 3) {
                            t.write(beep, 0, beep.size)
                            t.write(gap, 0, gap.size)
                        }
                        t.write(pause, 0, pause.size)
                    }
                } catch (e: Exception) {
                }
            }.also { it.start() }
        } catch (e: Exception) {
            synthRunning = false
            AlarmLog.d(ctx, "No pude generar pitidos: ${e.message}")
        }
    }

    fun stop() {
        synthRunning = false
        try { mp?.stop() } catch (e: Exception) { }
        try { mp?.release() } catch (e: Exception) { }
        mp = null
        try { track?.stop() } catch (e: Exception) { }
        try { track?.release() } catch (e: Exception) { }
        track = null
        thread?.interrupt()
        thread = null
    }
}
