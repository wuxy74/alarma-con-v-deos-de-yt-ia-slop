package com.despertador.ytalarm

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var cfg: Config
    private lateinit var urlEdit: EditText
    private lateinit var timeBtn: Button
    private val dayBoxes = ArrayList<CheckBox>()
    private lateinit var shuffleBox: CheckBox
    private lateinit var playerSpin: Spinner
    private lateinit var volBar: SeekBar
    private lateinit var volLabel: TextView
    private lateinit var durEdit: EditText
    private lateinit var toneBox: CheckBox
    private lateinit var permText: TextView
    private lateinit var statusText: TextView
    private lateinit var listText: TextView
    private var hour = 7
    private var minute = 0
    private var players: List<PlayerApp> = emptyList()
    private val handler = Handler(Looper.getMainLooper())

    private class Perm(val name: String, val ok: Boolean, val request: () -> Unit)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun label(text: String, size: Float = 16f, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        t.setPadding(0, dp(10), 0, dp(2))
        return t
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Config(this)
        players = Players.detect(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(32))
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("Despertador YouTube", 26f, true))
        root.addView(label("Suena aunque el móvil esté bloqueado o con la pantalla apagada. Con el móvil apagado del todo no puede sonar nada (solo si tiene \"encendido programado\")."))

        // --- permisos
        root.addView(label("Permisos", 20f, true))
        permText = label("")
        root.addView(permText)
        root.addView(button("Dar permisos (púlsalo hasta que todo ponga OK)") { requestNextPermission() })
        root.addView(button("Ajustes de la app (arranque automático, pantalla de bloqueo…)") { openAppSettings() })

        // --- vídeo
        root.addView(label("Vídeo o lista de reproducción", 20f, true))
        urlEdit = EditText(this)
        urlEdit.hint = "Pega aquí el enlace de YouTube"
        urlEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        root.addView(urlEdit)
        root.addView(button("Pegar enlace del portapapeles") { pasteLink() })
        shuffleBox = CheckBox(this)
        shuffleBox.text = "Si es una lista: empezar por un vídeo al azar (y seguir con los siguientes)"
        root.addView(shuffleBox)
        listText = label("", 14f)
        root.addView(listText)

        // --- hora
        root.addView(label("Hora", 20f, true))
        timeBtn = button("07:00") { pickTime() }
        timeBtn.textSize = 28f
        root.addView(timeBtn)
        root.addView(label("Repetir (si no marcas ningún día, suena una sola vez)", 14f))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (n in listOf("L", "M", "X", "J", "V", "S", "D")) {
            val cb = CheckBox(this)
            cb.text = n
            dayBoxes.add(cb)
            row.addView(cb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(row)

        // --- reproductor
        root.addView(label("Cómo reproducir el vídeo", 20f, true))
        playerSpin = Spinner(this)
        val names = ArrayList<String>()
        for (p in players) names.add("App: ${p.label} (${p.pkg})")
        names.add("Reproductor integrado en esta app (sobre el bloqueo)")
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        playerSpin.adapter = ad
        root.addView(playerSpin)
        if (players.isEmpty()) {
            root.addView(label("No encuentro YouTube ni ReVanced instalados; se usará el reproductor integrado.", 14f))
        }
        root.addView(label("Si el primer método no suena, la alarma prueba el otro automáticamente.", 14f))

        // --- volumen y duración
        volLabel = label("Volumen: 100 %")
        root.addView(volLabel)
        volBar = SeekBar(this)
        volBar.max = 100
        volBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { volLabel.text = "Volumen: $p %" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(volBar)

        root.addView(label("Minutos con la pantalla encendida; después la alarma se para sola (0 = 60 min y sin parada automática)", 14f))
        durEdit = EditText(this)
        durEdit.inputType = InputType.TYPE_CLASS_NUMBER
        root.addView(durEdit)

        toneBox = CheckBox(this)
        toneBox.text = "Si no suena el vídeo, usar el tono de alarma"
        root.addView(toneBox)

        // --- acciones
        statusText = label("", 18f, true)
        root.addView(statusText)
        root.addView(button("PROGRAMAR ALARMA") { schedule() })
        root.addView(button("Cancelar alarma") { cancelAlarm() })
        root.addView(button("Probar ahora") { testNow() })
        root.addView(button("Ver registro (para diagnosticar)") { showLog() })

        load()
    }

    override fun onResume() {
        super.onResume()
        refreshPerms()
        refreshStatus()
    }

    // ---------------------------------------------------------------- formulario

    private fun load() {
        urlEdit.setText(cfg.url)
        hour = cfg.hour
        minute = cfg.minute
        updateTimeBtn()
        for (i in 0 until 7) dayBoxes[i].isChecked = ((cfg.days shr i) and 1) == 1
        shuffleBox.isChecked = cfg.shuffle
        val sel = cfg.player
        var idx = when {
            sel.startsWith("app:") -> players.indexOfFirst { it.pkg == sel.removePrefix("app:") }
            sel == "embedded" -> players.size
            else -> 0
        }
        if (idx < 0) idx = 0
        playerSpin.setSelection(idx)
        volBar.progress = cfg.volume
        volLabel.text = "Volumen: ${cfg.volume} %"
        durEdit.setText(cfg.maxMin.toString())
        toneBox.isChecked = cfg.tone
    }

    /** Guarda el formulario. Devuelve false si el enlace no es válido. */
    private fun save(): Boolean {
        val url = urlEdit.text.toString().trim()
        if (YT.parse(url) == null) {
            Toast.makeText(this, "El enlace no es de un vídeo ni de una lista de YouTube", Toast.LENGTH_LONG).show()
            return false
        }
        cfg.url = url
        cfg.hour = hour
        cfg.minute = minute
        var mask = 0
        for (i in 0 until 7) if (dayBoxes[i].isChecked) mask = mask or (1 shl i)
        cfg.days = mask
        cfg.shuffle = shuffleBox.isChecked
        val pos = playerSpin.selectedItemPosition
        cfg.player = if (pos in players.indices) "app:" + players[pos].pkg else "embedded"
        cfg.volume = volBar.progress
        cfg.maxMin = (durEdit.text.toString().toIntOrNull() ?: 30).coerceIn(0, 720)
        cfg.tone = toneBox.isChecked
        return true
    }

    private fun pasteLink() {
        val cm = getSystemService(ClipboardManager::class.java)
        val txt = cm.primaryClip?.getItemAt(0)?.text?.toString()
        if (txt.isNullOrBlank()) {
            Toast.makeText(this, "No hay nada copiado", Toast.LENGTH_SHORT).show()
        } else {
            urlEdit.setText(txt.trim())
        }
    }

    private fun pickTime() {
        TimePickerDialog(this, { _, h, m ->
            hour = h
            minute = m
            updateTimeBtn()
        }, hour, minute, true).show()
    }

    private fun updateTimeBtn() {
        timeBtn.text = "%02d:%02d  (toca para cambiar)".format(hour, minute)
    }

    // ---------------------------------------------------------------- acciones

    private fun schedule() {
        if (!save()) return
        try {
            val t = Scheduler.schedule(this)
            cfg.enabled = true
            Toast.makeText(this, "Alarma programada: " + fmt(t), Toast.LENGTH_LONG).show()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Falta el permiso de alarmas exactas. Pulsa \"Dar permisos\".", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo programar: ${e.message}", Toast.LENGTH_LONG).show()
        }
        loadListInfo()
        refreshStatus()
    }

    private fun cancelAlarm() {
        Scheduler.cancel(this)
        refreshStatus()
        Toast.makeText(this, "Alarma cancelada", Toast.LENGTH_SHORT).show()
    }

    private fun testNow() {
        if (!save()) return
        if (AlarmService.instance != null) {
            Toast.makeText(this, "Ya hay una alarma sonando", Toast.LENGTH_SHORT).show()
            return
        }
        AlarmService.start(this, test = true, boot = false)
    }

    private fun loadListInfo() {
        val ref = YT.parse(cfg.url)
        val list = ref?.list
        if (list == null) {
            listText.text = ""
            return
        }
        listText.text = "Leyendo la lista…"
        Thread {
            val n = try { Playback.refresh(this, list) } catch (e: Exception) { 0 }
            runOnUiThread {
                listText.text = if (n > 0) "Lista leída: $n vídeos."
                else "No pude leer la lista ahora (sin internet o YouTube lo bloquea). La alarma lo intentará de nuevo y, si no puede, reproducirá la lista en su orden normal."
            }
        }.start()
    }

    private fun showLog() {
        val tv = TextView(this)
        tv.setPadding(dp(12), dp(8), dp(12), dp(8))
        tv.textSize = 12f
        tv.setTextIsSelectable(true)
        val text = AlarmLog.read(this)
        tv.text = if (text.isEmpty()) "(vacío)" else text
        val sv = ScrollView(this)
        sv.addView(tv)
        AlertDialog.Builder(this)
            .setTitle("Registro")
            .setView(sv)
            .setPositiveButton("Cerrar", null)
            .setNeutralButton("Borrar") { _, _ -> AlarmLog.clear(this) }
            .show()
        sv.post { sv.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun fmt(t: Long): String = SimpleDateFormat("EEEE d 'de' MMMM, HH:mm", Locale("es", "ES")).format(Date(t))

    private fun refreshStatus() {
        statusText.text = if (cfg.enabled && cfg.nextTrigger > System.currentTimeMillis())
            "ALARMA ACTIVADA: " + fmt(cfg.nextTrigger)
        else
            "ALARMA DESACTIVADA"
    }

    // ---------------------------------------------------------------- permisos

    private fun perms(): List<Perm> {
        val l = ArrayList<Perm>()
        val nm = getSystemService(NotificationManager::class.java)
        val notifOk = if (Build.VERSION.SDK_INT >= 33)
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        else nm.areNotificationsEnabled()
        l.add(Perm("Notificaciones", notifOk) { requestNotifications() })

        val exactOk = if (Build.VERSION.SDK_INT >= 31) getSystemService(AlarmManager::class.java).canScheduleExactAlarms() else true
        l.add(Perm("Alarmas exactas", exactOk) {
            openSetting(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        })

        l.add(Perm("Mostrar sobre otras apps (necesario para abrir el vídeo a la hora)", Settings.canDrawOverlays(this)) {
            openSetting(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        })

        val fsiOk = if (Build.VERSION.SDK_INT >= 34) nm.canUseFullScreenIntent() else true
        l.add(Perm("Notificaciones a pantalla completa (encender la pantalla)", fsiOk) {
            if (Build.VERSION.SDK_INT >= 34) openSetting(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
        })

        val batOk = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        l.add(Perm("Sin restricciones de batería", batOk) {
            openSetting(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        })
        return l
    }

    private fun refreshPerms() {
        val sb = StringBuilder()
        for (p in perms()) sb.append(if (p.ok) "[OK]  " else "[FALTA]  ").append(p.name).append('\n')
        permText.text = sb.toString().trimEnd()
    }

    private fun requestNextPermission() {
        val missing = perms().firstOrNull { !it.ok }
        if (missing == null) {
            Toast.makeText(this, "Todos los permisos están concedidos", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Concede: ${missing.name}", Toast.LENGTH_LONG).show()
        missing.request()
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && !cfg.askedNotif) {
            cfg.askedNotif = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        } else {
            try {
                startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                )
            } catch (e: Exception) {
                openAppSettings()
            }
        }
    }

    private fun openSetting(action: String) {
        try {
            startActivity(Intent(action, Uri.parse("package:$packageName")))
        } catch (e: ActivityNotFoundException) {
            openAppSettings()
        } catch (e: Exception) {
            openAppSettings()
        }
    }

    private fun openAppSettings() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            Toast.makeText(this, "No puedo abrir los ajustes", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshPerms()
    }
}
