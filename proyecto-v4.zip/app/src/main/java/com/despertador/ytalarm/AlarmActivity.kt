package com.despertador.ytalarm

import android.app.Activity
import android.app.KeyguardManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import org.json.JSONObject

/** Pantalla de alarma: se muestra sobre el bloqueo, enciende la pantalla y lanza el vídeo. */
class AlarmActivity : Activity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val EXTRA_ATTEMPT = "attempt"
        const val EXTRA_VIDEO = "video"
        const val EXTRA_LIST = "list"
        const val EXTRA_INDEX = "index"
        const val EXTRA_PKG = "pkg"

        @JvmStatic
        var instance: AlarmActivity? = null

        private const val PLAYER_HTML = """<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;padding:0;height:100%;background:#000;overflow:hidden}#p{width:100%;height:100%}</style>
</head><body><div id="p"></div>
<script>
var CFG = __CFG__;
var player = null, randomDone = false, skips = 0;
function say(fn, v){ try { Android[fn](v); } catch(e) {} }
var tag = document.createElement('script');
tag.src = 'https://www.youtube.com/iframe_api';
tag.onerror = function(){ say('onError', -1); };
document.head.appendChild(tag);
function onYouTubeIframeAPIReady(){
  var opts = { width:'100%', height:'100%',
    playerVars:{ autoplay:1, playsinline:1, rel:0, enablejsapi:1, origin:CFG.origin },
    events:{ onReady:onReady, onStateChange:onState, onError:onErr } };
  if (!CFG.list && CFG.video) opts.videoId = CFG.video;
  player = new YT.Player('p', opts);
}
function onReady(){
  try { player.unMute(); player.setVolume(100); } catch(e){}
  if (CFG.list) { player.loadPlaylist({ listType:'playlist', list:CFG.list, index:CFG.index }); }
  else { player.playVideo(); }
}
function onState(e){
  say('onState', e.data);
  if (e.data === 1) {
    try { player.unMute(); player.setVolume(100); } catch(x){}
    if (CFG.list && CFG.random && !randomDone) {
      randomDone = true;
      var ids = player.getPlaylist();
      if (ids && ids.length > 1) player.playVideoAt(Math.floor(Math.random() * ids.length));
    }
  }
}
function onErr(e){
  if (CFG.list && skips < 5) { skips++; try { player.nextVideo(); return; } catch(x){} }
  say('onError', e.data);
}
setTimeout(function(){ if (!player) say('onError', -2); }, 15000);
</script></body></html>"""
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var webHolder: FrameLayout
    private lateinit var openBtn: Button
    private var web: WebView? = null
    private var appPkg: String? = null
    private var opened = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)
        root.setPadding(dp(16), dp(32), dp(16), dp(24))

        val clock = TextClock(this)
        clock.format24Hour = "HH:mm"
        clock.format12Hour = "HH:mm"
        clock.setTextColor(Color.WHITE)
        clock.textSize = 64f
        clock.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(clock, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        status = TextView(this)
        status.setTextColor(Color.WHITE)
        status.textSize = 18f
        status.gravity = Gravity.CENTER_HORIZONTAL
        status.text = "Alarma"
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        webHolder = FrameLayout(this)
        root.addView(webHolder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        openBtn = Button(this)
        openBtn.text = "Abrir la app de YouTube"
        openBtn.isAllCaps = false
        openBtn.visibility = View.GONE
        openBtn.setOnClickListener { openYoutubeApp() }
        root.addView(openBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        val stop = Button(this)
        stop.text = "PARAR ALARMA"
        stop.textSize = 28f
        stop.setTextColor(Color.BLACK)
        stop.setBackgroundColor(Color.WHITE)
        stop.setOnClickListener {
            AlarmService.stop(this)
            finishAndRemoveTask()
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(120))
        lp.topMargin = dp(12)
        root.addView(stop, lp)

        setContentView(root)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    override fun onDestroy() {
        stopEmbedded()
        if (instance === this) instance = null
        super.onDestroy()
    }

    @Deprecated("La alarma no se cierra con Atrás; usa PARAR")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    // ---------------------------------------------------------------- instrucciones del servicio

    private fun handle(i: Intent) {
        val svc = AlarmService.instance
        val mode = i.getStringExtra(EXTRA_MODE)
        val attempt = i.getIntExtra(EXTRA_ATTEMPT, -1)
        if (svc == null) {
            status.text = "La alarma ya ha terminado."
            handler.postDelayed({ finishAndRemoveTask() }, 1500)
            return
        }
        if (mode == null) {
            svc.onUiReady()
            return
        }
        svc.onAck(attempt)
        when (mode) {
            AlarmService.MODE_APP -> launchApp(i, attempt)
            AlarmService.MODE_EMBEDDED -> startEmbedded(i, attempt)
        }
    }

    // ---------------------------------------------------------------- modo: app de YouTube / ReVanced

    private fun launchApp(i: Intent, attempt: Int) {
        stopEmbedded()
        val pkg = i.getStringExtra(EXTRA_PKG)
        if (pkg == null) {
            AlarmService.instance?.onUiEvent(attempt, "appfail")
            return
        }
        appPkg = pkg
        openBtn.visibility = View.VISIBLE
        val t = Target(i.getStringExtra(EXTRA_VIDEO), i.getStringExtra(EXTRA_LIST), i.getIntExtra(EXTRA_INDEX, -1))
        val url = YT.watchUrl(t)
        status.text = "Abriendo el vídeo en $pkg…"
        AlarmLog.d(this, "Abriendo $url con $pkg")
        opened = false

        val open = Runnable {
            if (opened) return@Runnable
            opened = true
            try {
                val v = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    .setPackage(pkg)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(v)
                status.text = "Reproduciendo en $pkg"
            } catch (e: ActivityNotFoundException) {
                AlarmLog.d(this, "$pkg no puede abrir el enlace")
                AlarmService.instance?.onUiEvent(attempt, "appfail")
            } catch (e: Exception) {
                AlarmLog.d(this, "Error abriendo $pkg: ${e.message}")
                AlarmService.instance?.onUiEvent(attempt, "appfail")
            }
        }

        // Pequeña espera para que la pantalla esté realmente encendida antes de abrir la app.
        val km = getSystemService(KeyguardManager::class.java)
        if (km.isKeyguardLocked && !km.isKeyguardSecure) {
            // Bloqueo sin PIN: se quita solo para que el vídeo se vea.
            handler.postDelayed({
                km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                    override fun onDismissSucceeded() { handler.post(open) }
                    override fun onDismissError() { handler.post(open) }
                    override fun onDismissCancelled() { handler.post(open) }
                })
            }, 700)
            handler.postDelayed(open, 3000)
        } else {
            handler.postDelayed(open, 1200)
        }
    }

    private fun openYoutubeApp() {
        val pkg = appPkg ?: return
        try {
            val li = packageManager.getLaunchIntentForPackage(pkg)
            if (li != null) startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            AlarmLog.d(this, "No pude abrir $pkg: ${e.message}")
        }
    }

    // ---------------------------------------------------------------- modo: reproductor integrado

    private fun startEmbedded(i: Intent, attempt: Int) {
        stopEmbedded()
        val video = i.getStringExtra(EXTRA_VIDEO)
        val list = i.getStringExtra(EXTRA_LIST)
        val idx = i.getIntExtra(EXTRA_INDEX, -1)
        val random = Config(this).shuffle && list != null && idx < 0
        status.text = "Reproductor integrado…"
        AlarmLog.d(this, "Reproductor integrado: vídeo=$video lista=$list posición=$idx")

        val w = WebView(this)
        web = w
        w.setBackgroundColor(Color.BLACK)
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        w.webChromeClient = WebChromeClient()
        w.webViewClient = WebViewClient()
        w.addJavascriptInterface(Bridge(attempt), "Android")
        webHolder.addView(w, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val origin = "https://" + packageName.lowercase()
        val cfg = JSONObject()
        cfg.put("video", video ?: JSONObject.NULL)
        cfg.put("list", list ?: JSONObject.NULL)
        cfg.put("index", maxOf(idx, 0))
        cfg.put("random", random)
        cfg.put("origin", origin)
        val html = PLAYER_HTML.replace("__CFG__", cfg.toString())
        w.loadDataWithBaseURL("$origin/", html, "text/html", "UTF-8", null)
    }

    fun stopEmbedded() {
        val w = web ?: return
        web = null
        try {
            w.stopLoading()
            w.loadUrl("about:blank")
            webHolder.removeView(w)
            w.destroy()
        } catch (e: Exception) {
        }
    }

    fun finishAlarm() {
        stopEmbedded()
        finishAndRemoveTask()
    }

    private inner class Bridge(private val attempt: Int) {
        @JavascriptInterface
        fun onState(state: Int) {
            if (state == 1) runOnUiThread { AlarmService.instance?.onUiEvent(attempt, "playing") }
        }

        @JavascriptInterface
        fun onError(code: Int) {
            AlarmLog.d(this@AlarmActivity, "Error del reproductor integrado: $code")
            runOnUiThread { AlarmService.instance?.onUiEvent(attempt, "error") }
        }
    }
}
