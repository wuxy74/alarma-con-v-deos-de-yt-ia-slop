package com.despertador.ytalarm

import java.net.URLDecoder
import java.util.Calendar

/** Lo que el usuario pegó: un vídeo, una lista, o ambos. */
data class Ref(val video: String?, val list: String?)

/** Lo que se reproducirá en esta alarma (ya con el vídeo elegido). index = posición 0-based en la lista, -1 si no se sabe. */
data class Target(val video: String?, val list: String?, val index: Int)

object YT {
    private val ID11 = Regex("^[A-Za-z0-9_-]{11}$")
    private val BARE_LIST = Regex("^(PL|UU|OL|FL|RD|LL|WL)[A-Za-z0-9_-]{8,}$")
    private val PLAYLIST_ITEM = Regex("\"playlistVideoRenderer\":\\{\"videoId\":\"([A-Za-z0-9_-]{11})\"")
    private val RSS_ITEM = Regex("<yt:videoId>([A-Za-z0-9_-]{11})</yt:videoId>")

    private fun dec(s: String): String = try {
        URLDecoder.decode(s, "UTF-8")
    } catch (e: Exception) {
        s
    }

    fun parse(raw: String): Ref? {
        var s = raw.trim().replace("&amp;", "&")
        if (s.isEmpty()) return null
        if (ID11.matches(s)) return Ref(s, null)
        if (BARE_LIST.matches(s)) return Ref(null, s)
        if (!s.contains("://")) s = "https://$s"

        val rest = s.substringAfter("://")
        val noFragment = rest.substringBefore('#')
        val beforeQuery = noFragment.substringBefore('?')
        val host = beforeQuery.substringBefore('/').substringBefore(':').lowercase()
        val path = beforeQuery.substringAfter('/', "").split('/').filter { it.isNotEmpty() }
        val query = noFragment.substringAfter('?', "")

        val params = HashMap<String, String>()
        for (p in query.split('&')) {
            if (!p.contains('=')) continue
            val k = p.substringBefore('=')
            if (k.isNotEmpty()) params[k] = dec(p.substringAfter('='))
        }

        var video: String? = null
        if (host == "youtu.be" || host.endsWith(".youtu.be")) {
            video = path.firstOrNull()
        } else if (host.endsWith("youtube.com") || host.endsWith("youtube-nocookie.com")) {
            video = params["v"]
            if (video == null && path.size >= 2 && path[0] in listOf("shorts", "embed", "live", "v")) {
                video = path[1]
            }
        } else {
            return null
        }
        if (video != null && !ID11.matches(video)) video = null
        val list = params["list"]?.takeIf { it.length >= 10 }
        if (video == null && list == null) return null
        return Ref(video, list)
    }

    /** Enlace que abre la app de YouTube (o ReVanced) reproduciendo directamente. */
    fun watchUrl(t: Target): String {
        val v = t.video
        val l = t.list
        return when {
            v != null && l != null ->
                "https://www.youtube.com/watch?v=$v&list=$l" + (if (t.index >= 0) "&index=${t.index + 1}" else "")
            v != null -> "https://www.youtube.com/watch?v=$v"
            l != null -> "https://www.youtube.com/watch?list=$l"
            else -> "https://www.youtube.com/"
        }
    }

    fun idsFromPlaylistHtml(html: String): List<String> =
        PLAYLIST_ITEM.findAll(html).map { it.groupValues[1] }.distinct().toList()

    fun idsFromRss(xml: String): List<String> =
        RSS_ITEM.findAll(xml).map { it.groupValues[1] }.distinct().toList()
}

object Clock {
    /** Máscara de días: bit0 = lunes ... bit6 = domingo. 0 = una sola vez. */
    fun nextTrigger(hour: Int, minute: Int, mask: Int, after: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = after
        c.set(Calendar.HOUR_OF_DAY, hour)
        c.set(Calendar.MINUTE, minute)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        for (i in 0..8) {
            if (c.timeInMillis > after) {
                val dow = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 // lunes=0 ... domingo=6
                if (mask == 0 || ((mask shr dow) and 1) == 1) return c.timeInMillis
            }
            c.add(Calendar.DAY_OF_MONTH, 1)
        }
        return c.timeInMillis
    }
}
