package com.despertador.ytalarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.UserManager
import android.view.KeyEvent
import kotlin.math.roundToInt

/**
 * Coordina la alarma: mantiene el móvil despierto, sube el volumen, abre la pantalla de alarma
 * y prueba los métodos de reproducción en orden (app de YouTube/ReVanced y reproductor integrado).
 * Si ninguno suena, usa el tono de alarma.
 */
class AlarmService : Service() {

    companion object {
        const val ACTION_START = "com.despertador.ytalarm.START"
        const val ACTION_STOP = "com.despertador.ytalarm.STOP"
        private const val EXTRA_BOOT = "boot"
        private const val CHANNEL = "alarma"
        private const val NOTIF_ID = 4242
        const val MODE_APP = "app"
        const val MODE_EMBEDDED = "embedded"

        @JvmStatic
        var instance: AlarmService? = null

        fun start(ctx: Context, test: Boolean, boot: Boolean) {
            AlarmLog.d(ctx, "Iniciando servicio (prueba=$test, arranque=$boot)")
            val i = Intent(ctx, AlarmService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_BOOT, boot)
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, AlarmService::class.java).setAction(ACTION_STOP))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var cfg: Config
    private var cpuLock: PowerManager.WakeLock? = null
    private var screenLock: PowerManager.WakeLock? = null
    private var tone: ToneAlarm? = null
    private var unlockReceiver: BroadcastReceiver? = null

    private var running = false
    private var stopped = false
    private var fromBoot = false
    private var usedApp = false

    private var plan: List<String> = emptyList()
    private var step = -1
    private var attempt = 0
    private var acked = false
    private var playing = false
    private var attemptStart = 0L
    private var deadline = 0L
    private var target = Target(null, null, -1)
    private var appPkg: String? = null
    private var tick: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        cfg = Config(this)
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL, "Alarma", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            log("Se ha pulsado PARAR")
            shutdown()
            return START_NOT_STICKY
        }
        startFg(notification("Preparando la alarma…", true))
        if (!running) {
            running = true
            instance = this
            begin(intent?.getBooleanExtra(EXTRA_BOOT, false) == true)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        releaseLocks()
        if (instance === this) instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- flujo principal

    private fun begin(boot: Boolean) {
        fromBoot = boot
        cfg = Config(this)
        log("=== ALARMA === enlace=${cfg.url} reproductor='${cfg.player}' azar=${cfg.shuffle} volumen=${cfg.volume}")
        acquireLocks()
        applyVolume()
        if (cfg.maxMin > 0) {
            handler.postDelayed({ log("Duración máxima alcanzada"); shutdown() }, cfg.maxMin * 60_000L)
        }

        val unlocked = getSystemService(UserManager::class.java).isUserUnlocked
        if (!unlocked) {
            log("El móvil sigue bloqueado tras arrancar: suena el tono hasta que lo desbloquees")
            startTone()
            launchUi(null)
            val r = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    log("Móvil desbloqueado")
                    try { unregisterReceiver(this) } catch (e: Exception) { }
                    unlockReceiver = null
                    stopTone()
                    preparePlan()
                }
            }
            unlockReceiver = r
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(r, IntentFilter(Intent.ACTION_USER_UNLOCKED), Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(r, IntentFilter(Intent.ACTION_USER_UNLOCKED))
            }
        } else {
            preparePlan()
        }
    }

    private fun preparePlan() {
        Thread {
            var t = Target(null, null, -1)
            try {
                t = Playback.resolve(this, true)
            } catch (e: Exception) {
                log("Error leyendo la lista: ${e.message}")
            }
            val apps = try { Players.detect(this) } catch (e: Exception) { emptyList() }
            handler.post { if (!stopped) onResolved(t, apps) }
        }.start()
    }

    private fun onResolved(t: Target, apps: List<PlayerApp>) {
        target = t
        val wantsApp = cfg.player.startsWith("app:") || cfg.player.isEmpty()
        val wanted = cfg.player.removePrefix("app:")
        appPkg = if (apps.any { it.pkg == wanted }) wanted else apps.firstOrNull()?.pkg
        val chain = if (cfg.player == "embedded") listOf(MODE_EMBEDDED, MODE_APP) else listOf(MODE_APP, MODE_EMBEDDED)
        plan = chain.filter { it != MODE_APP || appPkg != null }
        log("Vídeo=${t.video} lista=${t.list} posición=${t.index} app=$appPkg orden=$plan (wantsApp=$wantsApp)")
        if (t.video == null && t.list == null) {
            log("El enlace guardado no es válido")
            giveUp()
            return
        }
        nextStep()
    }

    private fun nextStep() {
        cancelTick()
        step++
        if (step >= plan.size) {
            giveUp()
            return
        }
        attempt++
        acked = false
        playing = false
        val timeout = if (fromBoot) 45_000L else 20_000L
        attemptStart = SystemClock.elapsedRealtime()
        deadline = attemptStart + timeout
        val mode = plan[step]
        if (mode == MODE_APP) usedApp = true
        log("Intento $attempt con '$mode' (máx. ${timeout / 1000}s)")
        updateNotif("Abriendo el vídeo…")
        launchUi(mode)

        val id = attempt
        val r = object : Runnable {
            override fun run() {
                if (stopped || id != attempt || playing) return
                if (audioActive()) {
                    markPlaying("audio detectado")
                    return
                }
                val now = SystemClock.elapsedRealtime()
                if (!acked && now - attemptStart > 8000) {
                    fail("la pantalla de alarma no se abrió")
                    return
                }
                if (now >= deadline) {
                    fail("sin sonido tras ${timeout / 1000}s")
                    return
                }
                handler.postDelayed(this, 1500)
            }
        }
        tick = r
        handler.postDelayed(r, 1500)
    }

    private fun fail(reason: String) {
        if (stopped) return
        log("Fallo: $reason")
        if (step in plan.indices && plan[step] == MODE_APP) pauseMedia()
        AlarmActivity.instance?.stopEmbedded()
        nextStep()
    }

    private fun markPlaying(why: String) {
        if (stopped) return
        playing = true
        cancelTick()
        log("Sonando ($why)")
        updateNotif("Reproduciendo el vídeo")
        val list = target.list
        if (list != null && cfg.idsAgeMs(list) > 12 * 3_600_000L) {
            Thread { try { Playback.refresh(this, list) } catch (e: Exception) { } }.start()
        }
    }

    private fun giveUp() {
        if (stopped) return
        log("Ningún método de vídeo funcionó")
        updateNotif("No se pudo reproducir el vídeo")
        if (cfg.tone) startTone()
    }

    private fun cancelTick() {
        tick?.let { handler.removeCallbacks(it) }
        tick = null
    }

    // ---------------------------------------------------------------- llamadas desde la pantalla de alarma

    fun onAck(id: Int) {
        if (id == attempt) {
            acked = true
            log("Pantalla de alarma lista (intento $id)")
        }
    }

    /** La pantalla de alarma se abrió sin instrucciones (p. ej. por la notificación): reenvía el intento actual. */
    fun onUiReady() {
        if (!stopped && step in plan.indices && !acked) launchUi(plan[step])
    }

    fun onUiEvent(id: Int, ev: String) {
        if (stopped || id != attempt) return
        when (ev) {
            "playing" -> markPlaying("reproductor integrado")
            "error" -> fail("error del reproductor integrado")
            "appfail" -> fail("no se pudo abrir la app de YouTube")
        }
    }

    // ---------------------------------------------------------------- piezas

    private fun launchUi(mode: String?) {
        val i = Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (mode != null) {
            i.putExtra(AlarmActivity.EXTRA_MODE, mode)
            i.putExtra(AlarmActivity.EXTRA_ATTEMPT, attempt)
            i.putExtra(AlarmActivity.EXTRA_VIDEO, target.video)
            i.putExtra(AlarmActivity.EXTRA_LIST, target.list)
            i.putExtra(AlarmActivity.EXTRA_INDEX, target.index)
            i.putExtra(AlarmActivity.EXTRA_PKG, appPkg)
        }
        try {
            startActivity(i)
        } catch (e: Exception) {
            log("No se pudo abrir la pantalla de alarma: ${e.message}")
        }
    }

    private fun audioActive(): Boolean = try {
        getSystemService(AudioManager::class.java).isMusicActive
    } catch (e: Exception) {
        false
    }

    private fun pauseMedia() {
        try {
            val am = getSystemService(AudioManager::class.java)
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE))
        } catch (e: Exception) {
            log("No pude pausar el reproductor: ${e.message}")
        }
    }

    private fun applyVolume() {
        try {
            val am = getSystemService(AudioManager::class.java)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val v = (max * cfg.volume.coerceIn(0, 100) / 100f).roundToInt().coerceAtLeast(1)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            log("Volumen multimedia: $v de $max")
        } catch (e: Exception) {
            log("No pude ajustar el volumen: ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        val pm = getSystemService(PowerManager::class.java)
        val ms = (if (cfg.maxMin > 0) cfg.maxMin else 60) * 60_000L
        try {
            cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ytalarm:cpu").also {
                it.setReferenceCounted(false)
                it.acquire(ms + 60_000L)
            }
            screenLock = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "ytalarm:screen"
            ).also {
                it.setReferenceCounted(false)
                it.acquire(ms)
            }
            log("Pantalla y CPU despiertas durante ${ms / 60_000} min")
        } catch (e: Exception) {
            log("No pude mantener el móvil despierto: ${e.message}")
        }
    }

    private fun releaseLocks() {
        try { if (screenLock?.isHeld == true) screenLock?.release() } catch (e: Exception) { }
        try { if (cpuLock?.isHeld == true) cpuLock?.release() } catch (e: Exception) { }
        screenLock = null
        cpuLock = null
    }

    private fun startTone() {
        if (tone == null) tone = ToneAlarm(this)
        tone?.start()
        log("Tono de alarma activado")
    }

    private fun stopTone() {
        tone?.stop()
        tone = null
    }

    private fun shutdown() {
        if (stopped) {
            stopSelf()
            return
        }
        stopped = true
        handler.removeCallbacksAndMessages(null)
        stopTone()
        if (usedApp) pauseMedia()
        unlockReceiver?.let { try { unregisterReceiver(it) } catch (e: Exception) { } }
        unlockReceiver = null
        AlarmActivity.instance?.finishAlarm()
        releaseLocks()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        running = false
        instance = null
        stopSelf()
        log("Alarma terminada")
    }

    // ---------------------------------------------------------------- notificación

    private fun startFg(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotif(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(text, false))
        } catch (e: Exception) {
        }
    }

    private fun notification(text: String, fullScreen: Boolean): Notification {
        val ui = PendingIntent.getActivity(
            this, 0,
            Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, AlarmService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val ab = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_pause), "PARAR", stopPi
        )
        if (Build.VERSION.SDK_INT >= 31) ab.setAuthenticationRequired(false)
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Despertador YouTube")
            .setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(ui)
            .addAction(ab.build())
        if (fullScreen) b.setFullScreenIntent(ui, true)
        return b.build()
    }

    private fun log(msg: String) = AlarmLog.d(this, msg)
}
