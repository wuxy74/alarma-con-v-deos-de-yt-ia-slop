package com.despertador.ytalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Ajustes. Se guardan en almacenamiento "device protected" para que la alarma funcione tras arrancar sin desbloquear. */
class Config(ctx: Context) {
    private val sp: SharedPreferences =
        ctx.createDeviceProtectedStorageContext().getSharedPreferences("cfg", Context.MODE_PRIVATE)

    var url: String
        get() = sp.getString("url", "") ?: ""
        set(v) { sp.edit().putString("url", v).apply() }

    var hour: Int
        get() = sp.getInt("hour", 7)
        set(v) { sp.edit().putInt("hour", v).apply() }

    var minute: Int
        get() = sp.getInt("minute", 0)
        set(v) { sp.edit().putInt("minute", v).apply() }

    /** bit0 = lunes ... bit6 = domingo; 0 = una sola vez */
    var days: Int
        get() = sp.getInt("days", 0)
        set(v) { sp.edit().putInt("days", v).apply() }

    var shuffle: Boolean
        get() = sp.getBoolean("shuffle", true)
        set(v) { sp.edit().putBoolean("shuffle", v).apply() }

    /** "" = automático, "app:<paquete>" o "embedded" */
    var player: String
        get() = sp.getString("player", "") ?: ""
        set(v) { sp.edit().putString("player", v).apply() }

    var volume: Int
        get() = sp.getInt("volume", 100)
        set(v) { sp.edit().putInt("volume", v).apply() }

    /** Minutos que la alarma mantiene la pantalla encendida y tras los que se para sola. 0 = 60 y sin parada. */
    var maxMin: Int
        get() = sp.getInt("maxMin", 30)
        set(v) { sp.edit().putInt("maxMin", v).apply() }

    var tone: Boolean
        get() = sp.getBoolean("tone", true)
        set(v) { sp.edit().putBoolean("tone", v).apply() }

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) { sp.edit().putBoolean("enabled", v).apply() }

    var nextTrigger: Long
        get() = sp.getLong("nextTrigger", 0L)
        set(v) { sp.edit().putLong("nextTrigger", v).apply() }

    var firedTrigger: Long
        get() = sp.getLong("firedTrigger", 0L)
        set(v) { sp.edit().putLong("firedTrigger", v).apply() }

    var askedNotif: Boolean
        get() = sp.getBoolean("askedNotif", false)
        set(v) { sp.edit().putBoolean("askedNotif", v).apply() }

    fun ids(list: String): List<String> =
        (sp.getString("ids_$list", "") ?: "").split(',').filter { it.isNotEmpty() }

    fun saveIds(list: String, ids: List<String>) {
        sp.edit().putString("ids_$list", ids.joinToString(",")).putLong("idsT_$list", System.currentTimeMillis()).apply()
    }

    fun idsAgeMs(list: String): Long = System.currentTimeMillis() - sp.getLong("idsT_$list", 0L)
}

/** Registro visible en la app (botón "Ver registro") y en logcat con la etiqueta DespertadorYT. */
object AlarmLog {
    private const val TAG = "DespertadorYT"

    private fun file(ctx: Context) = File(ctx.createDeviceProtectedStorageContext().filesDir, "ytalarm.log")

    @Synchronized
    fun d(ctx: Context, msg: String) {
        Log.d(TAG, msg)
        try {
            val f = file(ctx)
            if (f.exists() && f.length() > 60_000) f.writeText(f.readText().takeLast(30_000))
            val t = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date())
            f.appendText("$t  $msg\n")
        } catch (e: Exception) {
            Log.w(TAG, "No se pudo escribir el registro: ${e.message}")
        }
    }

    @Synchronized
    fun read(ctx: Context): String = try {
        file(ctx).readText()
    } catch (e: Exception) {
        ""
    }

    @Synchronized
    fun clear(ctx: Context) {
        try { file(ctx).delete() } catch (e: Exception) { }
    }
}

object Scheduler {
    private fun operation(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 1, Intent(ctx, AlarmReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    /** Programa la siguiente alarma con setAlarmClock (la más fiable: despierta el móvil en Doze). */
    fun schedule(ctx: Context, after: Long = System.currentTimeMillis()): Long {
        val c = Config(ctx)
        val t = Clock.nextTrigger(c.hour, c.minute, c.days, after)
        val am = ctx.getSystemService(AlarmManager::class.java)
        val show = PendingIntent.getActivity(
            ctx, 2, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(t, show), operation(ctx))
        c.nextTrigger = t
        AlarmLog.d(ctx, "Alarma programada para ${Date(t)}")
        return t
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(operation(ctx))
        Config(ctx).enabled = false
        AlarmLog.d(ctx, "Alarma cancelada")
    }

    /** Tras sonar: si se repite, programa la siguiente; si era de una sola vez, se desactiva. */
    fun afterFire(ctx: Context) {
        val c = Config(ctx)
        if (c.enabled && c.days != 0) {
            try {
                schedule(ctx, maxOf(System.currentTimeMillis(), c.nextTrigger) + 1000)
            } catch (e: Exception) {
                AlarmLog.d(ctx, "No pude reprogramar: ${e.message}")
            }
        } else {
            c.enabled = false
        }
    }
}
