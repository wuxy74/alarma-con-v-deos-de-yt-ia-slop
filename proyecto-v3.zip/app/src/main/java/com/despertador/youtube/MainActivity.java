package com.despertador.youtube;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText urlInput;
    private TimePicker picker;
    private CheckBox diaria;
    private CheckBox aleatorio;
    private CheckBox usarApp;
    private TextView estado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences p = Scheduler.prefs(this);

        ScrollView scroll = new ScrollView(this);
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setPadding(dp(16), dp(32), dp(16), dp(16));
        scroll.addView(raiz);

        TextView titulo = new TextView(this);
        titulo.setText("Despertador con YouTube");
        titulo.setTextSize(24);
        raiz.addView(titulo);

        urlInput = new EditText(this);
        urlInput.setHint("Enlace de un vídeo o de una lista");
        urlInput.setSingleLine(true);
        urlInput.setText(p.getString("url", ""));
        raiz.addView(urlInput);

        picker = new TimePicker(this);
        picker.setIs24HourView(true);
        picker.setHour(p.getInt("hour", 7));
        picker.setMinute(p.getInt("minute", 0));
        raiz.addView(picker);

        diaria = new CheckBox(this);
        diaria.setText("Repetir cada día");
        diaria.setChecked(p.getBoolean("daily", false));
        raiz.addView(diaria);

        aleatorio = new CheckBox(this);
        aleatorio.setText("Si es una lista, empezar por un vídeo al azar");
        aleatorio.setChecked(p.getBoolean("aleatorio", true));
        raiz.addView(aleatorio);

        usarApp = new CheckBox(this);
        usarApp.setText("Abrir en la app de YouTube (sin reproductor propio)");
        usarApp.setChecked(p.getBoolean("app", false));
        raiz.addView(usarApp);

        raiz.addView(boton("Programar alarma", v -> programar()));
        raiz.addView(boton("Cancelar alarma", v -> cancelar()));
        raiz.addView(boton("Probar ahora", v -> AlarmReceiver.disparar(this)));
        raiz.addView(boton("Dar permisos", v -> permisos()));

        estado = new TextView(this);
        estado.setTextSize(16);
        estado.setPadding(0, dp(16), 0, 0);
        raiz.addView(estado);

        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        actualizarEstado();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private Button boton(String texto, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(texto);
        b.setOnClickListener(l);
        return b;
    }

    private void aviso(String t) {
        Toast.makeText(this, t, Toast.LENGTH_LONG).show();
    }

    private void programar() {
        String url = urlInput.getText().toString().trim();
        if (url.isEmpty()) {
            aviso("Pega primero el enlace del vídeo o la lista");
            return;
        }
        picker.clearFocus();
        int h = picker.getHour();
        int m = picker.getMinute();
        Scheduler.prefs(this).edit()
                .putString("url", url)
                .putInt("hour", h)
                .putInt("minute", m)
                .putBoolean("daily", diaria.isChecked())
                .putBoolean("aleatorio", aleatorio.isChecked())
                .putBoolean("app", usarApp.isChecked())
                .apply();
        long t = Scheduler.programar(this, Scheduler.siguienteDisparo(h, m));
        if (t < 0) {
            aviso("Falta el permiso de alarmas exactas: actívalo y vuelve a programar");
            try {
                if (Build.VERSION.SDK_INT >= 31) {
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName())));
                }
            } catch (Exception e) {
                // Sin pantalla de ajustes disponible.
            }
        }
        actualizarEstado();
    }

    private void cancelar() {
        Scheduler.cancelar(this);
        actualizarEstado();
    }

    private void permisos() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            aviso("Activa «Mostrar sobre otras apps» para Despertador YouTube");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (!nm.canUseFullScreenIntent()) {
                aviso("Permite las notificaciones a pantalla completa");
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + getPackageName())));
                return;
            }
        }
        aviso("Todos los permisos están concedidos");
    }

    private void actualizarEstado() {
        SharedPreferences p = Scheduler.prefs(this);
        if (p.getBoolean("enabled", false)) {
            estado.setText("Alarma programada: "
                    + DateFormat.format("EEEE d MMM, HH:mm", p.getLong("trigger", 0)));
        } else {
            estado.setText("No hay ninguna alarma programada");
        }
    }
}
