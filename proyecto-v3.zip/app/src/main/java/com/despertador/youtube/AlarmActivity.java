package com.despertador.youtube;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;

public class AlarmActivity extends Activity {

    // Reproductor de YouTube con su API oficial: permite quitar el silencio,
    // elegir un vídeo al azar de una lista y seguir con los siguientes.
    private static final String HTML = """
            <!DOCTYPE html>
            <html><head>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
            html,body{margin:0;padding:0;height:100%;background:#000;overflow:hidden}
            #player{position:absolute;top:0;left:0;width:100%;height:100%}
            </style></head><body>
            <div id="player"></div>
            <script>
            var VIDEO = "__VIDEO__";
            var LISTA = "__LISTA__";
            var ALEATORIO = __ALEATORIO__;
            var player = null;
            var erroresSeguidos = 0;

            function fallo(c) { try { Android.fallo(c); } catch (e) {} }

            var tag = document.createElement('script');
            tag.src = "https://www.youtube.com/iframe_api";
            document.head.appendChild(tag);

            setTimeout(function () {
              if (!player || !player.getPlayerState) fallo(-1);
            }, 15000);

            function onYouTubeIframeAPIReady() {
              var vars = { playsinline: 1, controls: 1, rel: 0, fs: 0 };
              var opts = { width: '100%', height: '100%', playerVars: vars,
                           events: { onReady: listo, onStateChange: cambio, onError: error } };
              if (LISTA) { vars.listType = 'playlist'; vars.list = LISTA; }
              else { vars.autoplay = 1; opts.videoId = VIDEO; }
              player = new YT.Player('player', opts);
            }

            function listo(e) {
              e.target.unMute();
              e.target.setVolume(100);
              if (LISTA) { elegir(0); } else { e.target.playVideo(); }
            }

            function elegir(intento) {
              var pl = null;
              try { pl = player.getPlaylist(); } catch (x) {}
              if (!pl || !pl.length) {
                if (intento < 20) { setTimeout(function () { elegir(intento + 1); }, 500); }
                else { player.playVideo(); }
                return;
              }
              var i = 0;
              if (ALEATORIO) { i = Math.floor(Math.random() * pl.length); }
              else if (VIDEO) { i = Math.max(0, pl.indexOf(VIDEO)); }
              player.unMute();
              player.setVolume(100);
              player.playVideoAt(i);
            }

            function cambio(e) {
              if (e.data === 1) {
                erroresSeguidos = 0;
                player.unMute();
                player.setVolume(100);
              }
            }

            function error(e) {
              erroresSeguidos++;
              if (LISTA && erroresSeguidos < 5 && e.data !== 153) {
                player.nextVideo();
              } else {
                fallo(e.data);
              }
            }
            </script></body></html>
            """;

    private WebView web;
    private Ringtone tono;
    private boolean abiertoEnApp = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    // Si a los 30 s no suena nada, entra el tono de respaldo.
    private final Runnable comprobar = new Runnable() {
        @Override
        public void run() {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am == null || !am.isMusicActive()) sonarDeRespaldo();
        }
    };

    // Lo llama el reproductor cuando no puede reproducir (error de inserción, sin red...).
    private class Puente {
        @JavascriptInterface
        public void fallo(int codigo) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    abrirEnApp();
                }
            });
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.cancel(1);

        // Volumen multimedia al máximo.
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            am.setStreamVolume(AudioManager.STREAM_MUSIC,
                    am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
        } catch (Exception e) {
            // Sin permiso para cambiar el volumen: se queda como esté.
        }

        SharedPreferences p = Scheduler.prefs(this);
        String url = p.getString("url", "");
        boolean forzarApp = p.getBoolean("app", false);

        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(Color.BLACK);

        if (!forzarApp) {
            try {
                web = new WebView(this);
                WebSettings s = web.getSettings();
                s.setJavaScriptEnabled(true);
                s.setDomStorageEnabled(true);
                s.setMediaPlaybackRequiresUserGesture(false);
                web.setWebChromeClient(new WebChromeClient());
                web.addJavascriptInterface(new Puente(), "Android");
                web.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onReceivedError(WebView view, WebResourceRequest request,
                                                WebResourceError error) {
                        if (request.isForMainFrame()) sonarDeRespaldo();
                    }
                });
                raiz.addView(web, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
            } catch (Throwable t) {
                web = null;
                sonarDeRespaldo();
            }
        }

        Button parar = new Button(this);
        parar.setText("PARAR");
        parar.setTextSize(22);
        parar.setOnClickListener(v -> detener());
        int alto = (int) (90 * getResources().getDisplayMetrics().density);
        raiz.addView(parar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, alto));

        setContentView(raiz);

        if (forzarApp) {
            abrirEnApp();
        } else if (web != null) {
            String video = Scheduler.extraerVideo(url);
            String lista = Scheduler.extraerLista(url);
            if (video.isEmpty() && lista.isEmpty()) {
                web.loadUrl(Scheduler.normalizarUrl(url));
            } else {
                String html = HTML
                        .replace("__VIDEO__", video)
                        .replace("__LISTA__", lista)
                        .replace("__ALEATORIO__", p.getBoolean("aleatorio", true) ? "true" : "false");
                web.loadDataWithBaseURL("https://www.youtube.com", html,
                        "text/html", "utf-8", null);
            }
        }

        handler.postDelayed(comprobar, 30000);
        // Parada automática a los 30 minutos.
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                detener();
            }
        }, 30 * 60 * 1000L);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
    }

    // Abre el vídeo o la lista en la app de YouTube (o en el navegador si no está).
    private void abrirEnApp() {
        if (abiertoEnApp) return;
        abiertoEnApp = true;
        String url = Scheduler.urlParaApp(Scheduler.prefs(this).getString("url", ""));
        Intent yt = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        yt.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        yt.setPackage("com.google.android.youtube");
        try {
            startActivity(yt);
        } catch (Exception e) {
            yt.setPackage(null);
            try {
                startActivity(yt);
            } catch (Exception e2) {
                sonarDeRespaldo();
            }
        }
        if (web != null) web.loadUrl("about:blank");
    }

    private void sonarDeRespaldo() {
        if (tono != null) return;
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            tono = RingtoneManager.getRingtone(this, uri);
            tono.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            if (Build.VERSION.SDK_INT >= 28) tono.setLooping(true);
            tono.play();
        } catch (Throwable t) {
            // Sin tono de respaldo.
        }
    }

    private void limpiar() {
        handler.removeCallbacksAndMessages(null);
        if (tono != null) {
            tono.stop();
            tono = null;
        }
        if (web != null) {
            web.loadUrl("about:blank");
            web.destroy();
            web = null;
        }
    }

    private void detener() {
        limpiar();
        finish();
    }

    @Override
    protected void onDestroy() {
        limpiar();
        super.onDestroy();
    }
}
