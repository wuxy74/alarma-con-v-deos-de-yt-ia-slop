package com.despertador.youtube;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Scheduler {
    static final String PREFS = "despertador";
    static final String ACCION_ALARMA = "com.despertador.youtube.ALARMA";

    // Almacenamiento protegido por dispositivo: se puede leer aunque el móvil
    // se acabe de encender y todavía no lo hayas desbloqueado.
    static SharedPreferences prefs(Context c) {
        return c.createDeviceProtectedStorageContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static PendingIntent alarmaPending(Context c) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction(ACCION_ALARMA);
        return PendingIntent.getBroadcast(c, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static long siguienteDisparo(int hora, int minuto) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hora);
        cal.set(Calendar.MINUTE, minuto);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        return cal.getTimeInMillis();
    }

    // Devuelve la hora programada, o -1 si falta el permiso de alarmas exactas.
    static long programar(Context c, long momento) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Intent abrir = new Intent(c, MainActivity.class);
        PendingIntent abrirPi = PendingIntent.getActivity(c, 2, abrir,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(momento, abrirPi), alarmaPending(c));
        } catch (SecurityException e) {
            return -1;
        }
        prefs(c).edit().putBoolean("enabled", true).putLong("trigger", momento).apply();
        return momento;
    }

    static void cancelar(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(alarmaPending(c));
        prefs(c).edit().putBoolean("enabled", false).apply();
    }

    // Se llama al reiniciar el móvil: Android borra las alarmas al apagarse.
    static void restaurar(Context c) {
        SharedPreferences p = prefs(c);
        if (!p.getBoolean("enabled", false)) return;
        long momento = p.getLong("trigger", 0);
        long ahora = System.currentTimeMillis();
        if (momento > ahora) {
            programar(c, momento);
            return;
        }
        boolean diaria = p.getBoolean("daily", false);
        boolean reciente = ahora - momento < 15 * 60 * 1000L;
        if (diaria) {
            programar(c, siguienteDisparo(p.getInt("hour", 7), p.getInt("minute", 0)));
        } else {
            p.edit().putBoolean("enabled", false).apply();
        }
        // Si el móvil se encendió pocos minutos después de la hora, suena ya.
        if (reciente) AlarmReceiver.disparar(c);
    }

    static String normalizarUrl(String u) {
        u = (u == null) ? "" : u.trim();
        Matcher m = Pattern
                .compile("(?:youtu\\.be/|[?&]v=|/shorts/|/embed/|/live/)([A-Za-z0-9_-]{11})")
                .matcher(u);
        if (m.find()) return "https://m.youtube.com/watch?v=" + m.group(1);
        if (!u.startsWith("http")) u = "https://" + u;
        return u;
    }

    static String extraerVideo(String u) {
        if (u == null) return "";
        Matcher m = Pattern
                .compile("(?:youtu\\.be/|[?&]v=|/shorts/|/embed/|/live/)([A-Za-z0-9_-]{11})")
                .matcher(u);
        return m.find() ? m.group(1) : "";
    }

    static String extraerLista(String u) {
        if (u == null) return "";
        Matcher m = Pattern.compile("[?&]list=([A-Za-z0-9_-]+)").matcher(u);
        return m.find() ? m.group(1) : "";
    }

    // Dirección que se le pasa a la app de YouTube (conserva la lista si la hay).
    static String urlParaApp(String u) {
        String video = extraerVideo(u);
        String lista = extraerLista(u);
        if (!lista.isEmpty()) {
            return "https://www.youtube.com/watch?"
                    + (video.isEmpty() ? "" : "v=" + video + "&") + "list=" + lista;
        }
        if (!video.isEmpty()) return "https://www.youtube.com/watch?v=" + video;
        return normalizarUrl(u);
    }
}
