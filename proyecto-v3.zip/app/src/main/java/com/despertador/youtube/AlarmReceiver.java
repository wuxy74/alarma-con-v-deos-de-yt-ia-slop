package com.despertador.youtube;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class AlarmReceiver extends BroadcastReceiver {
    static final String CANAL = "alarma";

    @Override
    public void onReceive(Context c, Intent intent) {
        String accion = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(accion)
                || Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(accion)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(accion)) {
            Scheduler.restaurar(c);
            return;
        }

        // Ha llegado la hora.
        SharedPreferences p = Scheduler.prefs(c);
        if (p.getBoolean("daily", false)) {
            Scheduler.programar(c, Scheduler.siguienteDisparo(
                    p.getInt("hour", 7), p.getInt("minute", 0)));
        } else {
            p.edit().putBoolean("enabled", false).apply();
        }
        disparar(c);
    }

    static void disparar(Context c) {
        NotificationManager nm =
                (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel canal = new NotificationChannel(
                CANAL, "Alarma", NotificationManager.IMPORTANCE_HIGH);
        canal.setSound(null, null);
        nm.createNotificationChannel(canal);

        Intent i = new Intent(c, AlarmActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(c, 3, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Plan A: notificación con pantalla completa (lo que usan los despertadores).
        Notification n = new Notification.Builder(c, CANAL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Despertador")
                .setContentText("Toca para abrir el vídeo")
                .setCategory(Notification.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .build();
        nm.notify(1, n);

        // Plan B: abrir la pantalla directamente (funciona si Android lo permite).
        try {
            c.startActivity(i);
        } catch (Exception e) {
            // Si Android lo bloquea, ya está el plan A.
        }
    }
}
